# Easy Gnocchi Lasagna

[Full Recipe Link](https://kalekouture.org/skillet-gnocchi-lasagna/)
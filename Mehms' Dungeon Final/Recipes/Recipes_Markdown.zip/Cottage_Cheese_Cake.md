# (Cottage) Cheese Cake

[Full Recipe Link](https://www.alisoneroman.com/recipes/cottage-cheese-cake)
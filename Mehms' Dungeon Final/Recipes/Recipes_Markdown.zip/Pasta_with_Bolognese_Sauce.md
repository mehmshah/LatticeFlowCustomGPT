# Pasta with Bolognese Sauce

[Full Recipe Link](https://docs.google.com/document/d/1Wfu882IJOKI3VQWGjscM-u0OzXiKP3X91LBHTspL5Qg/edit#heading=h.1t9r4ixnhfix)
# Malaika Green Smoothie Cubes

**Meal Type**: Smoothie

**Cuisine / Dish Type**: Smoothie

**Tags**: None

## Ingredients
- 1 bunch steamed kale (cut the stems out, steamed until the leaves turned a bright green - maybe 1-2 mins) 
- 1 steamed broccoli heads + a couple stems (same as above but closer to 2- 3 mins, the goal is to get ride of the bitter taste) 
- 1 steamed cauliflower head 
- 1 raw zucchini 
- 1 cucumber 
- 3-4 cups of spinach 
- 1-2 avocado 
- parsley (I think 1 bunch)  
- mint (a shit ton I grabbed from the garden imo I wish I added more) 
- 1-2 juiced lemons (I find the lemon can be over powering, which can limit your smoothie flavour profile - so I try not to add too much) 
- 1 banana 
- 1 can of coconut milk
- water

"I put in 3 beets + beet leaves to a dif batch and it made them taste a little earthy. I would add beets again, but maybe 1 instead or 3 

I’d also want to experiment with carrots, apples, additional leafy greens, herbs, frozen peas and celery 

If you make them let me know how they turn out! I’m so excited to keep experimenting with the recipe"

_No link or detailed instructions provided._
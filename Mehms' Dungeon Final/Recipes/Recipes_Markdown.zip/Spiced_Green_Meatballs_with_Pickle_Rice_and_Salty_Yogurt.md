# Spiced Green Meatballs with Pickle Rice and Salty Yogurt

[Full Recipe Link](https://drive.google.com/file/d/1ZVn_4M8ntbuGSEL9VoZ7h65t8QoXURGB/view?usp=sharing)
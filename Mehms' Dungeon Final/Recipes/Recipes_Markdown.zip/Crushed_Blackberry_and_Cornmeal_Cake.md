# Crushed Blackberry and Cornmeal Cake

[Full Recipe Link](https://lambandwine.wordpress.com/2020/03/30/alison-romans-crushed-blackberry-and-cornmeal-cake/)
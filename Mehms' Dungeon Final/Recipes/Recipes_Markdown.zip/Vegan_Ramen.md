# Vegan Ramen

[Full Recipe Link](https://docs.google.com/document/d/1-DvhWRPWu-UuQiMJFM18p4zmbAqYpn6BnkVjdO7Wabo/edit#heading=h.6hfpk6x0w8se)
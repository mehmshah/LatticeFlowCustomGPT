# Soba Noodles with Mushrooms and Bok Choy

[Full Recipe Link](https://docs.google.com/document/d/1JJL2QmjWAbsMaPCeDdc50K0QEvcdp9RCVc_CwoGrx50/edit)
# Stella's Egg Bake

**Meal Type**: Breakfast

**Cuisine / Dish Type**: Breakfast

**Tags**: Takes Time

## Ingredients
- 18 eggs (but could do less for sure) 
- 1 cup cottage cheese
- 3 cups shredded cheddar 
- 6 potatoes 
- 1 head broccoli 
- sea salt & pepper

Cube potatoes and fry in oil until fully cooked (kind of like you’re making a hash) and add finely chopped broccoli in for the last few mins

In a blender, whip the eggs, cottage cheese, salt & pepper 

In a large baking dish, add all the fillings and then pour the egg mixture overtop 

Bake in the oven at 350 until eggs are set :) took a while lol like 45 mins to an hour
OH ALSO! I think the trick to more velvety texture is that you boil a few cups of water, and pour that into a separate baking dish that you put in the oven at the same time. The boiling water kind of steams the eggs in the oven so they are very soft and custardy!! 

_No link or detailed instructions provided._
# Kale Salad

**Meal Type**: Lunch/Dinner

**Cuisine / Dish Type**: Salad

**Tags**: GF / DF / Veg

## Ingredients
Kale
Parmesan
Pine nuts
Currants

Dressing:
1/4 cup olive oil
2 tbsp leom juice
1 tsp Dijon
1/2 tsp garlic, crushed
1/2 tsp salt
1/8 tsp pepper

_No link or detailed instructions provided._
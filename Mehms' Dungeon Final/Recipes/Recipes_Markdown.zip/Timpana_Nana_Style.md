# Timpana Nana Style

**Meal Type**: N/A

**Cuisine / Dish Type**: N/A

**Tags**: None

## Ingredients
2 tbsp olive oil
1 onion, finely chopped
3 garlic cloves, finely chopped
2 bay leaves
200 g minced beef 2 tbsp tomato paste
200 g canned chopped tomatoes
125 ml (½ cup) beef stock
pinch of grated nutmeg
250 g penne or other tubular pasta
60 g (¾ cup) finely grated parmesan
3 eggs 1 tbsp milk

_No link or detailed instructions provided._
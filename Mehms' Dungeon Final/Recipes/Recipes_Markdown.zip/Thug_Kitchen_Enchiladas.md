# Thug Kitchen Enchiladas

[Full Recipe Link](https://www.saymmm.com/recipe/thug-kitchen-sweet-potato-squash-black-bean-enchiladas---829)
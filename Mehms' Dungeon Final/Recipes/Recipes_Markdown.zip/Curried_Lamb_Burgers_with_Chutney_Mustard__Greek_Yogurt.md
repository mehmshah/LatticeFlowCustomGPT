# Curried Lamb Burgers with Chutney Mustard & Greek Yogurt

[Full Recipe Link](https://alexandracooks.com/2013/03/05/curried-lamb-burgers-with-chutney-mustard-greek-yogurt/)
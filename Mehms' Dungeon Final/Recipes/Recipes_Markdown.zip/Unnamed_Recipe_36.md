# Unnamed_Recipe_36

**Meal Type**: N/A

**Cuisine / Dish Type**: N/A

**Tags**: None

## Ingredients
Instructions Preheat oven to 220°C. 

Heat oil in a large, heavy-based pan over medium heat. Add onion and cook, stirring occasionally, for 7 minutes or until softened. Add garlic, bay leaves and cook for 4 mins. Add beef and cook, breaking up lumps with a wooden spoon, for 7 minutes or until browned. Add tomato paste and cook for 2 minutes, then add tomatoes, stock and nutmeg. Season with salt and pepper, and bring to the boil. Reduce heat to low and cook, covered, for 15 minutes or until liquid has reduced slightly. Remove from heat. Meanwhile cook pasta in a large pan of boiling salted water until al dente. Drain, add to sauce with parmesan and 2 lightly beaten eggs, mixing to combine. Cool.

_No link or detailed instructions provided._
# Elliot's Curry Chicken Salad

[Full Recipe Link](https://basicswithbabish.co/basicsepisodes/healthymeals)
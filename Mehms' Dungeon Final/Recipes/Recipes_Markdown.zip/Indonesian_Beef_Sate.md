# Indonesian Beef Sate

[Full Recipe Link](https://drive.google.com/drive/u/0/folders/1KOpLxlkAjMtUe6isqgaaQrM6AECsg2rz)
# Vegetarian Japchae (Korean Glass Noodles)

[Full Recipe Link](https://alexandracooks.com/2019/12/01/vegetarian-japchae-korean-glass-noodles/)
# Whole-Roasted Sweet Potato With Sunflower Gremolata And Lemony Sour Cream

[Full Recipe Link](https://thefeedfeed.com/edeneats/whole-roasted-sweet-potato-with-sunflower-gremolata-and-lemony-sour-cream)
# Dilly Bean Stew with Cabbage and Frizzled Onions

[Full Recipe Link](https://www.alisoneroman.com/recipes/dilly-bean-stew-with-cabbage-and-frizzled-onions)
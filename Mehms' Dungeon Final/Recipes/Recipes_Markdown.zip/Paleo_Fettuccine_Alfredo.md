# Paleo Fettuccine Alfredo

[Full Recipe Link](https://docs.google.com/document/d/1bAoVHqpTKDegSA6-CAa8jEAhCfYxKy9cYm4Fg8KAbWw/edit#)
# Falafel Fritters Bowl with Cucumbers and Yogurt Sauce

[Full Recipe Link](https://www.bonappetit.com/recipe/falafel-fritters-bowl-with-cucumbers-and-yogurt-sauce)
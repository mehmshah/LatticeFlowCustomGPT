# Pasta with Broccolini, Preserved Lemon and Chickpeas

[Full Recipe Link](https://www.feastingathome.com/pasta-with-broccolini-preserved-lemon-and-chickpeas/)
# Jesse's Bomb Ass Rice Soup

**Meal Type**: N/A

**Cuisine / Dish Type**: N/A

**Tags**: None

## Ingredients
Soup
Makes a large batch - I usually make it for dinner and have 3ish litres left to freeze
Heavy bottom pot is best

.5L brown rice
.5L wild rice
1 large carrot, diced
1 large sweet potato, diced
2L chicken Stock
2t ras el hanout or any tasty spice mix you enjoy
3-4 chicken thighs, de-veined

The day before soak the rice in water in the fridge to soften is 
Drain it off, saving the water and pretty aggressively try to break it into smaller pieces using your hands (this won’t really work for the wild rice but it’s ok)
Add the rice water, stock and chicken to the pot, and cook over medium heat until the chicken is poached and tender enough to pull. Remove from pot and let cool until you can pull it.
Add the rice, and additional 1L of water into the pot
Bring to a boil and cover, stirring frequently to avoid scorching the pot
After 1.5 hours, add your veg, pulled chicken and spices and lower heat to medium.
Season with salt to taste and let simmer until the vegetables are for tender.
Season with salt to taste and add more spices if needed. Also add water at this stage if you want it a bit thinner, all preference.

At home, I’ll often chop up some baby spinach and add it to the bottom of each bowl before putting the soup in. Nice way to add more veg.
Enjoy!!!

_No link or detailed instructions provided._
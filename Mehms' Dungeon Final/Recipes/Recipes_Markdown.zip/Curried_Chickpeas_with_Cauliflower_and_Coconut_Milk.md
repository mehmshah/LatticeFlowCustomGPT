# Curried Chickpeas with Cauliflower and Coconut Milk

[Full Recipe Link](https://docs.google.com/document/d/1hlBQrKiyI9vfOmLGYhRENdeV8-vabXSJsHe1N-aILlY/edit#)
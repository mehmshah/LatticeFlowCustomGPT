# Dolma

[Full Recipe Link](https://docs.google.com/document/d/1ESpg5BlV_pepov1FuHrvuUWHHXxQ5n2uu9ZgdRhwkVk/edit)